EasyEncoder CLI - Cross-Platform ionCube Encoder Client
=========================================================

EasyEncoder CLI is a lightweight, cross-platform command-line client
designed to compile and protect PHP source files with official ionCube
encoders directly via the EasyEncoder REST API (https://phpvault.eu.cc).

Key Features:
- Single-file and entire-directory recursive encoding.
- Supports PHP 7.1, 7.2, 7.4, 8.1, 8.2, 8.3, and 8.4.
- ionCube ASCII, Binary, and Max Obfuscation profiles.
- Automatic comment & PHPDoc stripping for minimal bytecode footprint.
- Optional custom header and copyright comments.
- Concurrent multi-threaded directory processing.
- Cross-platform: Windows, Linux, macOS (Intel & Apple Silicon), FreeBSD.

QUICK START:
1. Check your account credits:
   easyencoder -key edk_your_api_key credits

2. Save your API key permanently to ~/.easyencoder/config.json:
   easyencoder config -key edk_your_api_key

3. Encode a single PHP script:
   easyencoder -i my_script.php -o my_script.encoded.php -php 8.2

4. Encode an entire project folder:
   easyencoder -i ./src -o ./dist -type ioncube_max -concurrency 8

For more help:
   easyencoder help
